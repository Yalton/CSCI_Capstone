Drop the Pmw directory into C:\Python22\Lib\site-packages\

For a good time, run the All.py script located at C:\Python22\Lib\site-packages\Pmw\Pmw_1_\demos 

Enjoy!